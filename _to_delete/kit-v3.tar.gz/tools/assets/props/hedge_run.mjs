import { Mesh } from '../../lib/mesh.mjs';

/** Clipped hedge. Blocks jitter so a long run does not read as one extrusion. */

export const tags = ["park","green","boundary"];

export default () => {
  const m = new Mesh();
  // slight per-block jitter so a run of these does not read as one extrusion
  for (let i = 0; i < 5; i++) {
    const h = 1.1 + (i % 3) * 0.07;
    m.box('foliage', { size: [0.82, h, 0.76 + (i % 2) * 0.06], pos: [i * 0.8 - 1.6, h / 2, 0] });
  }
  return m;
};
