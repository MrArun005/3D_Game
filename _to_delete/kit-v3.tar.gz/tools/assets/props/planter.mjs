import { Mesh } from '../../lib/mesh.mjs';

/** Precast street planter. */

export const tags = ["street","kerb","green"];

export default () => new Mesh()
  .box('concrete_precast', { size: [1.5, 0.6, 0.7], pos: [0, 0.3, 0] })
  .box('concrete_precast', { size: [1.6, 0.09, 0.8], pos: [0, 0.62, 0] })
  .box('foliage', { size: [1.3, 0.12, 0.5], pos: [0, 0.6, 0] });
