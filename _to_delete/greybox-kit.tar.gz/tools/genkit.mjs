#!/usr/bin/env node
/**
 * Generate the greybox asset kit into assets/source/.
 *
 *   npm run genkit          write every asset
 *   npm run genkit -- --list  print the catalogue without writing
 *
 * These are BLOCKOUTS: correct proportions, correct UVs, correct library
 * materials, correct origins — and no surface detail. The intended workflow is
 * to open one in Blender, keep the proportions, and model on top. Regenerating
 * OVERWRITES, so once you have refined an asset by hand, remove it from this
 * file or it will be clobbered on the next run. See docs/PIPELINE.md.
 */
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { writeGlb, writeTags } from './lib/gltf.mjs';
import * as facade from './kits/facade.mjs';
import * as street from './kits/street.mjs';
import * as park from './kits/park.mjs';
import * as signage from './kits/signage.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SRC = path.join(ROOT, 'assets/source');
const LIST_ONLY = process.argv.includes('--list');

/* Tags drive procedural placement — a rule asks for "something tagged kerb",
 * it never names an asset. That is how the city gains variety with no code
 * change. Keep these meaningful; they are the placement vocabulary. */
const TAGS = {
  // facade
  bay_glass_office: ['bay', 'commercial', 'modern'],
  bay_precast_office: ['bay', 'commercial', 'modern'],
  bay_brick_residential: ['bay', 'residential', 'period'],
  bay_tenement: ['bay', 'residential', 'period'],
  bay_warehouse: ['bay', 'industrial', 'period'],
  bay_plaster_upper: ['bay', 'residential', 'mixed'],
  ground_shopfront: ['ground', 'retail'],
  ground_shopfront_awning: ['ground', 'retail'],
  ground_lobby: ['ground', 'commercial'],
  ground_garage: ['ground', 'industrial', 'service'],
  ground_service: ['ground', 'service'],
  ground_cafe: ['ground', 'retail', 'spillout'],
  pilaster: ['vertical', 'period'],
  quoin_corner: ['vertical', 'corner', 'period'],
  downpipe: ['vertical', 'service'],
  fire_escape: ['vertical', 'industrial', 'rear'],
  balcony: ['vertical', 'residential'],
  string_course: ['band', 'period'],
  cornice_simple: ['topper', 'modern'],
  cornice_ornate: ['topper', 'period'],
  parapet: ['topper'],
  mansard: ['topper', 'period', 'roof'],
  // roof
  hvac_unit: ['roof', 'plant'],
  water_tank: ['roof', 'plant', 'landmark'],
  vent_stack: ['roof', 'plant'],
  aerial_mast: ['roof', 'plant', 'landmark'],
  roof_hut: ['roof', 'access'],
  skylight: ['roof'],
  plant_enclosure: ['roof', 'plant'],
  // street
  lamp_arterial: ['street', 'kerb', 'lighting', 'arterial'],
  lamp_local: ['street', 'kerb', 'lighting', 'local'],
  traffic_signal: ['street', 'junction'],
  sign_gantry: ['street', 'junction', 'arterial'],
  street_sign: ['street', 'kerb', 'junction'],
  bin: ['street', 'kerb', 'clutter'],
  bollard: ['street', 'kerb', 'clutter'],
  hydrant: ['street', 'kerb', 'clutter'],
  parking_meter: ['street', 'kerb', 'clutter'],
  post_box: ['street', 'kerb', 'clutter'],
  phone_box: ['street', 'kerb'],
  bus_shelter: ['street', 'kerb', 'transit'],
  bench: ['street', 'kerb', 'seating'],
  planter: ['street', 'kerb', 'green'],
  junction_box: ['street', 'kerb', 'service'],
  manhole: ['street', 'road', 'flat'],
  drain_grate: ['street', 'kerb', 'flat'],
  bike_rack: ['street', 'kerb', 'clutter'],
  // barriers
  cone: ['roadworks', 'clutter'],
  barrier: ['roadworks'],
  fence_panel: ['boundary', 'industrial'],
  railing: ['boundary', 'kerb'],
  hoarding: ['boundary', 'roadworks'],
  scaffold_bay: ['roadworks', 'facade'],
  // harbour
  quay_edge: ['harbour', 'edge'],
  mooring_bollard: ['harbour', 'edge', 'clutter'],
  quay_ladder: ['harbour', 'edge'],
  dock_crane: ['harbour', 'landmark'],
  container: ['harbour', 'industrial'],
  container_stack: ['harbour', 'industrial'],
  pontoon: ['harbour', 'water'],
  ferry_ramp: ['harbour', 'edge', 'transit'],
  crates: ['harbour', 'clutter'],
  pallet_stack: ['harbour', 'industrial', 'clutter'],
  // park
  path_segment: ['park', 'path', 'flat'],
  path_junction: ['park', 'path', 'flat'],
  hedge_run: ['park', 'green', 'boundary'],
  flower_bed: ['park', 'green'],
  park_bench: ['park', 'seating'],
  picnic_table: ['park', 'seating'],
  bandstand: ['park', 'landmark'],
  fountain: ['park', 'landmark', 'water'],
  notice_board: ['park', 'clutter'],
  park_gate: ['park', 'entrance', 'landmark'],
  swing_set: ['park', 'playground'],
  slide: ['park', 'playground'],
  climbing_frame: ['park', 'playground'],
  basketball_hoop: ['park', 'sport'],
  goalposts: ['park', 'sport'],
  pond_edge: ['park', 'water', 'edge'],
  litter_bin_park: ['park', 'clutter'],
  tree_blockout: ['park', 'green', 'tree', 'placeholder'],
  shrub_blockout: ['park', 'green', 'placeholder'],
  // signage
  sign_projecting: ['signage', 'facade', 'retail'],
  sign_wall_box: ['signage', 'facade', 'retail'],
  billboard_wall: ['signage', 'facade'],
  billboard_freestanding: ['signage', 'street'],
  banner_pole: ['signage', 'street', 'kerb'],
  a_frame_sign: ['signage', 'spillout', 'clutter'],
  market_stall: ['street', 'spillout', 'market'],
  cafe_umbrella: ['street', 'spillout', 'seating'],
  utility_pole: ['street', 'kerb', 'service'],
};

/* Facade modules live in their own category because they carry a 400-tri budget
 * and are instanced far more heavily than anything else. The rest of the facade
 * file is the roof kit, which is ordinary props. */
const FACADE_MODULES = new Set([
  'bay_glass_office', 'bay_precast_office', 'bay_brick_residential',
  'bay_tenement', 'bay_warehouse', 'bay_plaster_upper',
  'ground_shopfront', 'ground_shopfront_awning', 'ground_lobby',
  'ground_garage', 'ground_service', 'ground_cafe',
  'pilaster', 'quoin_corner', 'downpipe', 'fire_escape', 'balcony',
  'string_course', 'cornice_simple', 'cornice_ornate', 'parapet', 'mansard',
]);

const KITS = [
  ['facade', facade, (n) => FACADE_MODULES.has(n)],
  ['props', facade, (n) => !FACADE_MODULES.has(n)],
  ['props', street, () => true],
  ['props', park, () => true],
  ['props', signage, () => true],
];

async function main() {
  const rows = [];
  for (const [category, kit, accepts] of KITS) {
    for (const [name, fn] of Object.entries(kit)) {
      if (typeof fn !== 'function' || !accepts(name)) continue;
      const mesh = fn();
      mesh.seat();
      const b = mesh.bounds();
      const tags = TAGS[name] ?? [];
      rows.push({
        category, name, tris: mesh.tris,
        size: [b.max[0] - b.min[0], b.max[1] - b.min[1], b.max[2] - b.min[2]],
        tags,
      });
      if (LIST_ONLY) continue;
      const dir = path.join(SRC, category, name);
      await writeGlb(mesh, { name, category, dir });
      await writeTags(dir, tags);
    }
  }

  rows.sort((a, b) => a.category.localeCompare(b.category) || a.name.localeCompare(b.name));
  for (const r of rows) {
    console.log(
      `${r.category.padEnd(8)} ${r.name.padEnd(24)} ${String(r.tris).padStart(4)}t  ` +
      `${r.size.map((v) => v.toFixed(2)).join(' x ')}  ${r.tags.join(' ')}`
    );
  }
  const total = rows.reduce((n, r) => n + r.tris, 0);
  console.log(`\n${rows.length} assets, ${total} triangles total` +
    (LIST_ONLY ? ' (nothing written)' : ` -> ${path.relative(ROOT, SRC)}/`));
  const untagged = rows.filter((r) => !r.tags.length).map((r) => r.name);
  if (untagged.length) console.log(`\nuntagged (will not be placed): ${untagged.join(', ')}`);
}

main().catch((e) => { console.error(e); process.exit(1); });
