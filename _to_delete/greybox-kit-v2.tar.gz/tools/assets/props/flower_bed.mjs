import { Mesh } from '../../lib/mesh.mjs';

/** Kerbed planting bed. */

export const tags = ["park","green"];

export default () => new Mesh()
  .box('kerb_stone', { size: [2.6, 0.24, 1.6], pos: [0, 0.12, 0] })
  .box('timber_bare', { size: [2.3, 0.16, 1.3], pos: [0, 0.3, 0] })
  .box('timber_bare', { size: [1.6, 0.26, 0.8], pos: [-0.2, 0.4, 0.1] });
