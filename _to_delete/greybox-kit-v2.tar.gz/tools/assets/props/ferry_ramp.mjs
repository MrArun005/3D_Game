import { Mesh } from '../../lib/mesh.mjs';

/** Vehicle ferry ramp with side rails. */

export const tags = ["harbour","edge","transit"];

export default () => new Mesh()
  .wedge('concrete_cast', { size: [6.0, 1.2, 4.0], flip: true })
  .box('metal_rust', { size: [5.6, 0.14, 3.0], pos: [0, 0.9, 0.4], rot: [-0.14, 0, 0] })
  .box('metal_painted', { size: [0.12, 1.1, 3.0], pos: [-2.9, 1.4, 0.4] })
  .box('metal_painted', { size: [0.12, 1.1, 3.0], pos: [2.9, 1.4, 0.4] });
