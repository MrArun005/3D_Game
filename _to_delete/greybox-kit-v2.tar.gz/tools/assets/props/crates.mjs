import { Mesh } from '../../lib/mesh.mjs';

/** Loose timber crates. */

export const tags = ["harbour","clutter"];

export default () => new Mesh()
  .box('timber_bare', { size: [1.2, 0.9, 1.0], pos: [-0.5, 0.45, 0] })
  .box('timber_bare', { size: [1.0, 0.8, 0.9], pos: [0.7, 0.4, 0.2] })
  .box('timber_bare', { size: [0.9, 0.7, 0.8], pos: [-0.3, 1.25, -0.1], rot: [0, 0.4, 0] });
