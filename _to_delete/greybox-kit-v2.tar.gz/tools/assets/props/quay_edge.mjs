import { Mesh } from '../../lib/mesh.mjs';

/** Quay wall section with timber fenders. */

export const tags = ["harbour","edge"];

export default () => new Mesh()
  .box('concrete_cast', { size: [4.0, 1.6, 1.2], pos: [0, 0.8, 0] })
  .box('stone_dressed', { size: [4.0, 0.22, 1.4], pos: [0, 1.71, 0] })
  .box('timber_bare', { size: [0.3, 1.4, 0.22], pos: [-1.3, 0.7, 0.6] })
  .box('timber_bare', { size: [0.3, 1.4, 0.22], pos: [1.3, 0.7, 0.6] });
