# tools/assets

One file per asset. **There is no registry** — adding a file adds an asset,
deleting a file removes it. `tools/genkit.mjs` discovers everything here.

```
tools/assets/<category>/<name>.mjs
```

`category` decides the triangle budget (`facade` 400, `props` 300/900/2500 by
tag — see `docs/BUDGETS.md`) and where the output lands.

Each file looks like this:

```js
import { Mesh } from '../../lib/mesh.mjs';

/** One line saying what this is and when to use it. */

export const tags = ['street', 'kerb', 'clutter'];

export default () => new Mesh()
  .cylinder('metal_painted', { r: [0.24, 0.28], h: 0.86, seg: 10 })
  .box('metal_painted', { size: [0.06, 0.5, 0.06], pos: [0, 0.25, 0.3] });
```

- **default export** — a function returning a `Mesh`. `genkit` calls `.seat()`
  on it, so build from y=0 upward and do not worry about the exact origin.
- **`tags`** — the placement vocabulary. Rules ask for "something tagged `kerb`",
  never for an asset by name. An untagged asset is generated but never placed.
- **materials** — names must come from the library in `docs/ART_BIBLE.md`.
  `tools/ingest.mjs` fails on anything else, deliberately.

Facade modules import shared parts (`BAY`, storey heights, `opening`,
`punched`) from `../../lib/facade-parts.mjs`. Those constants are a contract
with the assembly code — changing them changes every building.

## Adding an asset

1. Write the file.
2. `npm run genkit -- <name>` to build just that one, or `npm run genkit` for all.
3. `npm run ingest` to validate, optimise, LOD and add it to the manifest.

## Refining an asset by hand

These are blockouts. When you open one in Blender and model on top of it,
**delete its generator file** — otherwise the next `npm run genkit` overwrites
your work. The `.glb` in `assets/source/` then becomes the authored source and
lives in git like any other art file.

## Building geometry

`tools/lib/mesh.mjs` gives you `box`, `cylinder`, `wedge`, `slab`, `quad` and
`repeatX`. UVs are planar-projected from world dimensions, so texel density is
correct automatically — a bin and a wall sampling the same concrete show the
same grain size. Use `skip: ['py','ny']` on a box to drop faces nobody sees.
