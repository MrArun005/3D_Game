import { Mesh } from '../../lib/mesh.mjs';
import { BAY } from '../../lib/facade-parts.mjs';

/** Two-step modern cornice. */

export const tags = ["topper","modern"];

export default () => new Mesh()
  .box('concrete_precast', { size: [BAY, 0.26, 0.5], pos: [0, 0.13, -0.1] })
  .box('concrete_precast', { size: [BAY, 0.2, 0.36], pos: [0, 0.36, -0.16] });
