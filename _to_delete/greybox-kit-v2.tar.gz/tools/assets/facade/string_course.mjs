import { Mesh } from '../../lib/mesh.mjs';
import { BAY } from '../../lib/facade-parts.mjs';

/** Horizontal band. Use to break a facade between storey groups. */

export const tags = ["band","period"];

export default () => new Mesh()
  .box('stone_dressed', { size: [BAY, 0.22, 0.14], pos: [0, 0.11, 0.02] });
