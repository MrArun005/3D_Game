import { Mesh } from '../../lib/mesh.mjs';
import { BAY } from '../../lib/facade-parts.mjs';

/** Mansard roof storey with a dormer. */

export const tags = ["topper","period","roof"];

export default () => new Mesh()
  .box('metal_galv', { size: [BAY, 2.0, 1.4], pos: [0, 1.0, -1.0], rot: [-0.32, 0, 0] })
  .box('stone_dressed', { size: [BAY, 0.16, 0.5], pos: [0, 0.08, -0.15] })
  .box('timber_painted', { size: [0.85, 0.9, 0.7], pos: [0, 1.05, -0.95] })
  .box('glass_shop', { size: [0.62, 0.7, 0.04], pos: [0, 1.08, -0.62] });
