import { Mesh } from '../../lib/mesh.mjs';

/** Rear fire escape: platform, rails and a run of stair. */

export const tags = ["vertical","industrial","rear"];

export default () => {
  const m = new Mesh();
  m.box('metal_rust', { size: [2.4, 0.07, 1.2], pos: [0, 0.9, -0.6] });          // platform
  m.repeatX(9, 0.28, (x) => m.box('metal_rust', { size: [0.04, 0.04, 1.2], pos: [x, 0.94, -0.6] }));
  for (const z of [-0.02, -1.18]) {
    m.box('metal_rust', { size: [2.4, 0.05, 0.05], pos: [0, 1.9, z] });
    m.repeatX(3, 1.1, (x) => m.box('metal_rust', { size: [0.05, 1.0, 0.05], pos: [x, 1.4, z] }));
  }
  m.box('metal_rust', { size: [0.05, 2.6, 0.05], pos: [-0.4, 2.2, -1.15], rot: [0.5, 0, 0] });
  m.box('metal_rust', { size: [0.05, 2.6, 0.05], pos: [0.4, 2.2, -1.15], rot: [0.5, 0, 0] });
  return m;
};
