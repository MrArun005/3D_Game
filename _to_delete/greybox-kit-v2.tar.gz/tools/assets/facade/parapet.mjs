import { Mesh } from '../../lib/mesh.mjs';
import { BAY } from '../../lib/facade-parts.mjs';

/** Solid parapet with a stone coping. Hides roof clutter from the street. */

export const tags = ["topper"];

export default () => new Mesh()
  .box('brick_painted', { size: [BAY, 1.05, 0.35], pos: [0, 0.525, -0.17] })
  .box('stone_dressed', { size: [BAY, 0.12, 0.45], pos: [0, 1.11, -0.17] });
