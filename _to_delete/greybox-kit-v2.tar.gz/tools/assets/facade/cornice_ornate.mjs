import { Mesh } from '../../lib/mesh.mjs';
import { BAY } from '../../lib/facade-parts.mjs';

/** Deep period cornice with a projecting drip. */

export const tags = ["topper","period"];

export default () => new Mesh()
  .box('stone_dressed', { size: [BAY, 0.18, 0.62], pos: [0, 0.09, -0.06] })
  .box('stone_dressed', { size: [BAY, 0.14, 0.5], pos: [0, 0.25, -0.12] })
  .box('stone_dressed', { size: [BAY, 0.3, 0.38], pos: [0, 0.47, -0.18] })
  .box('stone_dressed', { size: [BAY, 0.12, 0.7], pos: [0, 0.68, -0.04] });
